import math
class Korok:
    def __init__(self, x,y,r):
        self.x=x
        self.y=y
        self.r=r
    
