document.getElementById('save').addEventListener('click', function() {
    const url = document.getElementById('url').value;
    chrome.storage.sync.set({"baseURL": url}, function() {
        alert('Settings saved');
    });
});
