## **Acounto Labelstudio Chrome Extension**

#### Hogyan telepítsd
1. Töltsd le a projektet zip fájlként vagy clónozd a repo-t.
2. Chrome bővítményeknél kapcsold be a fejlesztői módot.
3. Töltsd be a kicsomagolt elemet.
4. Használd :D.


#### Fejlesztés
A bővítmény részleteinél a bővítménybeállításokra kattintva módosítani lehet az url-t a fejlesztéshez pl.: "https:bo2.acounto.com/" (fontos a végén a / jel).