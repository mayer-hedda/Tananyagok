chrome.runtime.onMessage.addListener((message, sender) => {
    if (message.action === "labelstudio") {
        const previousTabId = sender.tab.id;
        let baseUrl = message.baseURL + "*";

        // Look for the target tab to modify
        chrome.tabs.query({url: baseUrl}, function(tabs) {
            if (tabs.length) {
                const tabToUpdate = tabs[0];
                
                // Update the URL of the target tab and set it as the active tab
                chrome.tabs.update(tabToUpdate.id, {url: message.url, highlighted: true}, function() {
                    
                    setTimeout(() => {
                        chrome.tabs.reload(previousTabId);
                    }, 1000); // 1 seconds delay
                });
            }
        });
    }

    else if(message.action === "bo2") {
        let url = message.url + "*";

        chrome.tabs.query({url: url}, function(tabs) {
            if (tabs.length) {
                const tabToUpdate = tabs[0];

                // Update the URL of the target tab and set it as the active tab
                chrome.tabs.update(tabToUpdate.id, {selected: true}, function() {
                });
            }
        });
    }
});