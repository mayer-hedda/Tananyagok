function replaceLabelstudioButtonFunctionality() {
    let button = document.querySelector('button[aria-label="skip-task"]');
    let id = document.querySelector('div[class="lsf-current-task__task-id"]');
    
    if (button) {
        button.innerText = "BO2";
        id = id.innerText.split("\n")[0];

        chrome.storage.sync.get('baseURL', function(data) {
            let baseUrl = data.baseURL || 'https://bo2.acounto.com/'; // Default URL if not set
            let url = baseUrl + "ml/" + id;
            
            let confirmed = sessionStorage.getItem("confirmed");
            if(!confirmed) {
                sessionStorage.setItem("confirmed", confirm(`Bizonyosodj meg róla, hogy meg van nyitva a ${baseUrl} oldal.`));
            }

            button.addEventListener("click", function(event) {
                event.preventDefault();
                chrome.runtime.sendMessage({action: "labelstudio", baseURL: baseUrl, url: url});
            });
        });


        // If the button is found and handled, we can disconnect the observer
        if(observer) {
            console.log("observer disconnect")
            observer.disconnect();
        }
    }
}

function replaceBO2ButtonFunctionality() {
    let buttons = document.querySelector('div[class="labelstudio-actions"]');

    if(buttons) {
        buttons = buttons.getElementsByTagName('div');
        let url = 'https://label-uat.acounto.com/';

        chrome.storage.sync.get(function(data) {
            for(let button of buttons) {
                let btn = button.getElementsByClassName('text-white');
                if(btn.length) {
                    button.addEventListener("click", function() {
                        chrome.runtime.sendMessage({action: "bo2", url: url});
                    })
                }
            };
        });
        // If the button is found and handled, we can disconnect the observer
        if(observer) {
            observer.disconnect();
        }
    }

    
} 




let pageUrl = window.location.href;

function startObserver() {
    console.log("Observer started")
    if (pageUrl.match(/^https:\/\/label-uat\.acounto\.com/)) {
        window.observer = new MutationObserver(replaceLabelstudioButtonFunctionality);
        window.observer.observe(document.body, { childList: true, subtree: true });
    }
    else if (pageUrl.match(/http:\/\/localhost:8080\/.*/) || pageUrl.match(/http:\/\/127.0.0.1:8080\/.*/) || pageUrl.match(/https:\/\/uatbo2.acounto.com\/.*/) || pageUrl.match(/https:\/\/bo2.acounto.com\/.*/)) {
        window.observer = new MutationObserver(replaceBO2ButtonFunctionality);
        window.observer.observe(document.body, { childList: true, subtree: true });
    }
}

function onSubmitClick() {
    location.reload();
}

console.log("Extension loaded")

let submitObserver = new MutationObserver(() => {
    let submitButton = document.querySelector('button[aria-label="submit"].lsf-button.lsf-button_look_primary');
    if (submitButton) {
        submitButton.removeEventListener('click', onSubmitClick)
        submitButton.addEventListener('click', onSubmitClick);
    }
});
// Start the observer initially
startObserver();
submitObserver.observe(document.body, { childList: true, subtree: true });
// Add event listener to "Submit" button to start the observer again when clicked
